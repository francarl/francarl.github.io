// ==UserScript==
// @name         Zoolz
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Loads and executes JavaScript from a specified URL.
// @author       You
// @match        https://*.zoolz.co.uk/*
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // --- Configuration ---
    const remoteJsUrl = 'https://francarl.github.io/zoolz/zoolz_video_playlist.moz.js'; // Replace with the actual URL of the JS file

    // --- Script Logic ---
    GM_xmlhttpRequest({
        method: 'GET',
        url: remoteJsUrl,
        onload: function(response) {
            if (response.status >= 200 && response.status < 300) {
                try {
                    eval(response.responseText);
                    console.log(`Tampermonkey: Successfully loaded and executed script from ${remoteJsUrl}`);
                } catch (error) {
                    console.error(`Tampermonkey: Error executing script from ${remoteJsUrl}:`, error);
                }
            } else {
                console.error(`Tampermonkey: Failed to load script from ${remoteJsUrl}. Status: ${response.status}`);
            }
        },
        onerror: function(error) {
            console.error(`Tampermonkey: Error during GM_xmlhttpRequest to ${remoteJsUrl}:`, error);
        }
    });
})();