(function(){const _0x482315=JSON['parse']('\x22background.js\x22');import(chrome['runtime']['getURL'](_0x482315));}());
