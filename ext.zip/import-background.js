(function(){const _0x155d77=JSON['parse']('\x22background.js\x22');import(chrome['runtime']['getURL'](_0x155d77));}());
